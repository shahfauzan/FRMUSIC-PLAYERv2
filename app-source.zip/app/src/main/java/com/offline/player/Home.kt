package com.offline.player

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import androidx.compose.foundation.lazy.staggeredgrid.itemsIndexed as gridItemsIndexed

/** A collection earns the "Gold Record" badge once its tracks have been listened to this many times in total. */
const val GOLD_PLAYS = 20
private const val RECENT_COUNT = 30

private class HomeCard(val key: String, val title: String, val subtitle: String, val art: Any?, val gold: Boolean, val open: () -> Unit)

private val homeChips = listOf("All", "Trending", "Recent", "New Artist", "New Releases")

// ───────────────────────── Home ─────────────────────────

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    app: AppState, chip: Int, onChip: (Int) -> Unit, loaded: Boolean, granted: Boolean,
    onRequest: () -> Unit, onSettings: () -> Unit, onOpen: (Detail) -> Unit,
    onSearch: () -> Unit, onLiked: () -> Unit, onProfile: () -> Unit
) {
    val u = LocalUi.current
    val ps = app.ps
    val plays = app.prefs.plays

    val cards = remember(chip, app.songs, app.pls.lists, plays) {
        fun total(l: List<Song>) = l.sumOf { plays[it.id] ?: 0 }
        fun songCards(list: List<Song>) = list.mapIndexed { i, s ->
            HomeCard("s${s.id}", s.title, s.artist, s.art, false) { ps.playSongs(list, i) }
        }
        when (chip) {
            1 -> songCards(app.songs.filter { (plays[it.id] ?: 0) > 0 }.sortedByDescending { plays[it.id] ?: 0 }.take(RECENT_COUNT))
            2 -> songCards(app.songs.sortedWith(compareByDescending<Song> { it.dateAdded }.thenByDescending { it.id }).take(RECENT_COUNT))
            3 -> app.songs.groupBy { it.artist }.entries
                .sortedByDescending { e -> e.value.minOf { it.dateAdded } }.take(RECENT_COUNT)
                .map { (name, l) -> HomeCard("r$name", name, "${l.size} songs", l.first().art, total(l) >= GOLD_PLAYS) { onOpen(Detail.Artist(name)) } }
            4 -> app.songs.groupBy { it.albumId }.entries
                .sortedWith(compareByDescending<Map.Entry<Long, List<Song>>> { e -> e.value.maxOf { it.year } }.thenByDescending { e -> e.value.maxOf { it.dateAdded } })
                .take(RECENT_COUNT)
                .map { (id, l) -> HomeCard("a$id", l.first().album.ifBlank { "Unknown album" }, "${l.size} songs", l.first().art, total(l) >= GOLD_PLAYS) { onOpen(Detail.Album(id)) } }
            else -> {
                val pls = app.pls.lists.map { pl ->
                    val l = pl.songIds.mapNotNull { app.byId[it] }
                    HomeCard("p${pl.id}", pl.name, "${l.size} songs", l.firstOrNull()?.art, total(l) >= GOLD_PLAYS) { onOpen(Detail.PL(pl.id)) }
                }
                val albums = app.songs.groupBy { it.albumId }.map { (id, l) ->
                    HomeCard("a$id", l.first().album.ifBlank { "Unknown album" }, "${l.size} songs", l.first().art, total(l) >= GOLD_PLAYS) { onOpen(Detail.Album(id)) }
                }.sortedBy { it.title.lowercase() }
                pls + albums
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(app, onProfile)
            Spacer(Modifier.weight(1f))
            GlassCircleBtn(P.Search, "Search music", onSearch)
            Spacer(Modifier.width(8.dp))
            GlassCircleBtn(P.HeartOutline, "Liked songs", onLiked)
        }
        Text(
            if (app.prefs.userName.isBlank()) "Hello" else "Hello, ${app.prefs.userName}",
            fontSize = 28.sp, fontWeight = FontWeight.Medium, color = u.text, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 20.dp)
        )
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(homeChips) { i, n -> Chip(n, chip == i) { onChip(i) } }
        }
        when {
            !granted -> Message("Allow access to your music so the app can find your songs.") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Allow music access", true, onRequest); Chip("App settings", onClick = onSettings)
                }
            }
            cards.isEmpty() && loaded -> Message(
                when {
                    app.songs.isEmpty() -> "No music found on this device."
                    chip == 1 -> "Nothing here yet. Tracks you listen to for 30 seconds or more show up in Trending."
                    else -> "Nothing to show yet."
                }
            )
            else -> LazyVerticalStaggeredGrid(
                StaggeredGridCells.Fixed(2), Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 12.dp),
                verticalItemSpacing = 12.dp, horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                gridItemsIndexed(cards, key = { _, c -> c.key }) { i, c ->
                    val h = listOf(230, 170, 190, 215, 170, 200)[i % 6]
                    HomeTile(c, h)
                }
            }
        }
    }
}

@Composable
private fun HomeTile(c: HomeCard, heightDp: Int) {
    Box(
        Modifier.fillMaxWidth().height(heightDp.dp).clip(RoundedCornerShape(22.dp))
            .clickable(onClickLabel = "Open ${c.title}", onClick = c.open)
    ) {
        ArtFill(c.art, c.title, Modifier.fillMaxSize())
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(96.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.72f))))
        )
        if (c.gold) {
            val pill = RoundedCornerShape(50)
            Text(
                "Gold Record", fontSize = 11.sp, color = Color.White,
                modifier = Modifier.padding(10.dp).clip(pill).background(Color.Black.copy(.35f))
                    .border(1.dp, Color.White.copy(.45f), pill).padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
        Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
            Text(c.title, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(c.subtitle, fontSize = 11.sp, color = Color.White.copy(.82f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun Avatar(app: AppState, onClick: () -> Unit) {
    val u = LocalUi.current
    val name = app.prefs.userName
    Box(
        Modifier.size(48.dp).clip(CircleShape).background(u.accent)
            .semantics { contentDescription = "Profile. Opens settings to change your name or photo" }
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (app.prefs.avatarRev > 0) AsyncImage(app.prefs.avatarFile, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(name.take(1).uppercase().ifBlank { "♪" }, color = u.onAccent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

// ───────────────────────── My Music ─────────────────────────

private val musicChips = listOf("All", "Albums", "Artists", "Playlist", "Downloads", "Liked Songs")

class AlbumItem(val id: Long, val name: String, val artist: String, val songs: List<Song>)

@Composable
fun MyMusicScreen(
    app: AppState, results: List<Song>, query: String, onQuery: (String) -> Unit,
    chip: Int, onChip: (Int) -> Unit, searchOn: Boolean, onSearchToggle: () -> Unit,
    loaded: Boolean, granted: Boolean, onRequest: () -> Unit, onSettings: () -> Unit,
    onBack: () -> Unit, onLiked: () -> Unit, onOpen: (Detail) -> Unit
) {
    val u = LocalUi.current
    val ps = app.ps
    val favs = app.prefs.favs
    val songMode = chip == 0 || chip == 4 || chip == 5
    val list = remember(results, chip, favs) {
        when (chip) { 4 -> results.filter { it.inDownloads }; 5 -> results.filter { it.id in favs }; else -> results }
    }
    val liked = chip == 5

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            GlassCircleBtn(P.ChevronLeft, "Back to Home", onBack)
            Text("My Music", fontSize = 18.sp, fontWeight = FontWeight.Medium, color = u.text, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            GlassCircleBtn(if (searchOn) P.Close else P.Search, if (searchOn) "Close search" else "Search music", onSearchToggle)
            Spacer(Modifier.width(8.dp))
            GlassCircleBtn(if (liked) P.Heart else P.HeartOutline, "Liked songs", onLiked, tint = if (liked) u.accent else u.text)
        }
        if (searchOn) SearchField(query, onQuery, Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(musicChips) { i, n -> Chip(n, chip == i) { onChip(i) } }
            if (songMode) item {
                var open by remember { mutableStateOf(false) }
                Box {
                    Chip("Sort: ${sorts[app.prefs.sort]}") { open = true }
                    DropdownMenu(open, { open = false }) {
                        sorts.forEachIndexed { i, n -> DropdownMenuItem(text = { Text(n) }, onClick = { open = false; app.prefs.setSort(i) }) }
                    }
                }
            }
            if (query.isNotBlank() || (songMode && app.prefs.sort != 0)) item { Chip("Reset") { onQuery(""); app.prefs.setSort(0) } }
        }
        when {
            !granted -> Message("Allow access to your music so the app can find your songs.") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Allow music access", true, onRequest); Chip("App settings", onClick = onSettings)
                }
            }
            chip == 3 -> PlaylistsList(app, onOpen)
            chip == 1 -> {
                val albums = remember(results) {
                    results.groupBy { it.albumId }.map { (id, l) ->
                        val artists = l.map { it.artist }.distinct()
                        AlbumItem(id, l.first().album.ifBlank { "Unknown album" }, if (artists.size == 1) artists[0] else "Various artists", l)
                    }.sortedBy { it.name.lowercase() }
                }
                if (albums.isEmpty() && loaded) Message(if (query.isBlank()) "No albums found." else "No results for “$query”.")
                LazyColumn(Modifier.fillMaxSize()) {
                    items(albums, key = { it.id }) { a -> BrowseRow(a.songs.first(), a.name, "${a.artist} · ${a.songs.size} songs") { onOpen(Detail.Album(a.id)) } }
                }
            }
            chip == 2 -> {
                val artists = remember(results) { results.groupBy { it.artist }.toList().sortedBy { it.first.lowercase() } }
                if (artists.isEmpty() && loaded) Message(if (query.isBlank()) "No artists found." else "No results for “$query”.")
                LazyColumn(Modifier.fillMaxSize()) {
                    items(artists, key = { it.first }) { (name, l) ->
                        BrowseRow(l.first(), name, "${l.size} songs · ${l.map { it.albumId }.distinct().size} albums") { onOpen(Detail.Artist(name)) }
                    }
                }
            }
            else -> {
                if (list.isEmpty() && loaded) {
                    when {
                        query.isNotBlank() -> Message("No results for “$query”.")
                        app.songs.isEmpty() -> Message("No music found on this device.")
                        chip == 4 -> Message("No music found in your Downloads folder.")
                        chip == 5 -> Message("No liked songs yet. Tap the heart on Now Playing or use a song’s menu.")
                    }
                }
                LazyColumn(Modifier.fillMaxSize()) {
                    itemsIndexed(list, key = { _, s -> s.id }) { i, s ->
                        MusicRow(app, s, ps.current?.mediaId == s.id.toString(), { ps.playSongs(list, i) })
                    }
                }
            }
        }
    }
}

/** Track row from the reference: art, title/artist, duration, round play button. The menu holds queue/playlist/favorite actions. */
@Composable
fun MusicRow(app: AppState, s: Song, current: Boolean, onClick: () -> Unit, extras: List<Pair<String, () -> Unit>> = emptyList()) {
    val u = LocalUi.current
    val ps = app.ps
    val act = { if (current) ps.toggle() else onClick() }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp).clip(RoundedCornerShape(16.dp))
            .then(if (current) Modifier.background(u.accent.copy(.20f)) else Modifier)
            .clickable(onClickLabel = if (current) "Play or pause ${s.title}" else "Play ${s.title}") { act() }
            .padding(start = 6.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Art(s.art, s.title, 48.dp, 10.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (current) u.accentText else u.text)
            Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = u.dim)
        }
        Text(fmt(s.durationMs), fontSize = 11.sp, color = u.dim)
        SongMenu(app, s, extras)
        Box(
            Modifier.size(48.dp).semantics { contentDescription = if (current && ps.playing) "Pause" else "Play ${s.title}" }
                .clickable(role = Role.Button) { act() },
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(u.glassHi).border(1.dp, u.border, CircleShape),
                contentAlignment = Alignment.Center
            ) { Ico(if (current && ps.playing) P.Pause else P.Play, u.text, 20.dp) }
        }
    }
}

@Composable
private fun BrowseRow(song: Song, title: String, subtitle: String, onClick: () -> Unit) {
    val u = LocalUi.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp).clip(RoundedCornerShape(16.dp))
            .clickable(onClickLabel = "Open $title", onClick = onClick).padding(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Art(song.art, title, 56.dp, 12.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium, color = u.text)
            Text(subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = u.dim)
        }
    }
}

// ───────────────────────── Floating navigation pill ─────────────────────────

@Composable
fun FloatNav(tab: Int, onTab: (Int) -> Unit) {
    val u = LocalUi.current
    val items = listOf(Triple("Home", P.Home, 0), Triple("My Music", P.Note, 1), Triple("Online", GLOBE, 3), Triple("Settings", P.Gear, 2))
    Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
        Row(Modifier.glass(34.dp).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items.forEach { (label, icon, i) ->
                val sel = tab == i
                Box(
                    Modifier.size(52.dp).clip(CircleShape)
                        .then(if (sel) Modifier.background(u.accent) else Modifier)
                        .semantics { contentDescription = label }
                        .selectable(selected = sel, role = Role.Tab, onClick = { onTab(i) }),
                    contentAlignment = Alignment.Center
                ) { Ico(icon, if (sel) u.onAccent else u.dim, 24.dp) }
            }
        }
    }
}
