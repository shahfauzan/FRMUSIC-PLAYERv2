package com.offline.player

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Song(
    val id: Long, val title: String, val artist: String, val album: String,
    val albumId: Long, val durationMs: Long, val uri: Uri,
    val dateAdded: Long = 0L, val track: Int = 0,
    val year: Int = 0, val inDownloads: Boolean = false
) {
    /** Pre-lowercased search haystack, built once so searching large libraries stays cheap. */
    val key: String = "$title $artist $album".lowercase()

    val art: Uri
        get() = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)

    fun toItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title).setArtist(artist).setAlbumTitle(album).setArtworkUri(art).build()
        ).build()
}

val sorts = listOf("Title", "Artist", "Newest", "Oldest")

fun sortSongs(l: List<Song>, mode: Int): List<Song> = when (mode) {
    1 -> l.sortedWith(compareBy<Song>({ it.artist.lowercase() }, { it.title.lowercase() }))
    2 -> l.sortedWith(compareByDescending<Song> { it.dateAdded }.thenByDescending { it.id })
    3 -> l.sortedWith(compareBy<Song>({ it.dateAdded }, { it.id }))
    else -> l.sortedBy { it.title.lowercase() }
}

/** Reads the MediaStore music library. Safe to call off the main thread; returns empty on failure. */
fun loadSongs(ctx: Context): List<Song> {
    val out = ArrayList<Song>()
    val m = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    // RELATIVE_PATH exists from Android 10; older versions expose the file path through DATA.
    val pathCol = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.RELATIVE_PATH else MediaStore.Audio.Media.DATA
    val proj = arrayOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION,
        MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.TRACK, MediaStore.Audio.Media.YEAR, pathCol
    )
    try {
        ctx.contentResolver.query(
            m, proj, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iT = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iAr = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAl = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iAid = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val iD = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iDa = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val iTr = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val iY = c.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
            val iP = c.getColumnIndexOrThrow(pathCol)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                out.add(
                    Song(
                        id,
                        c.getString(iT)?.takeIf { it.isNotBlank() } ?: "Unknown",
                        c.getString(iAr)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Unknown artist",
                        c.getString(iAl)?.takeIf { it != "<unknown>" } ?: "",
                        c.getLong(iAid), c.getLong(iD),
                        ContentUris.withAppendedId(m, id),
                        c.getLong(iDa), c.getInt(iTr), c.getInt(iY),
                        c.getString(iP)?.let {
                            if (Build.VERSION.SDK_INT >= 29) it.startsWith("Download", ignoreCase = true)
                            else it.contains("/Download/", ignoreCase = true)
                        } ?: false
                    )
                )
            }
        }
    } catch (e: SecurityException) {
        // permission revoked mid-session
    } catch (e: IllegalArgumentException) {
        // vendor MediaStore missing a column
    }
    return out
}
